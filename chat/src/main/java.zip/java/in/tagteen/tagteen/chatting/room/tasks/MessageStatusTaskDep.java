package in.tagteen.tagteen.chatting.room.tasks;

import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;

import java.util.List;

import in.tagteen.tagteen.chatting.room.Message;

/**
 * Created by tony00 on 6/1/2019.
 */
public class MessageStatusTaskDep implements TaskRunnable {

    private String receiverId;
    private String serverMessageId;
    private int messageType = -1;
    private int status;
    private Handler handler;
    private OnMessageStatusChangedListener callback;

    public MessageStatusTaskDep(@NonNull String receiverId,
                                @Nullable String serverMessageId,
                                @Message.Status int status) {
        Log.d(TAG, "Updating Message Status: " + status);
        this.receiverId = receiverId;
        this.serverMessageId = serverMessageId;
        this.status = status;
    }

    public MessageStatusTaskDep(@NonNull String clientId,
                                @Message.Type int messageType,
                                @Message.Status int status) {
        this(clientId, null, status);
        this.messageType = messageType;

        handler = new Handler(Looper.getMainLooper()) {
            @Override
            public void handleMessage(android.os.Message msg) {
                super.handleMessage(msg);
                Bundle bundle = msg.getData();
                String[] messageIds = null;

                if (bundle != null)
                   messageIds = bundle.getStringArray(UpdateExecutor.DATA_MESSAGE_IDS);

                if (callback != null)
                    callback.onStatusChanged(messageIds);
            }
        };
    }

    @Override
    public void run() {
        if (status == Message.DELIVERED) {
            dB.updateMessageStatus(receiverId,
                                        status,
                    serverMessageId);
        } else {
            UpdateExecutor executor = new UpdateExecutor(receiverId,
                    messageType,
                    status,
                    handler);
            executor.execute();
        }
    }

    public void setOnMessageStatusChangedListener(OnMessageStatusChangedListener callback) {
        this.callback = callback;
    }

    private static class UpdateExecutor extends AsyncTask<Void, Void, List<String>> {

        static final String DATA_MESSAGE_IDS = "UpdateExecutor.MessageIds";

        private String receiverId;
        private int messageType;
        private int status;
        private Handler handler;

        UpdateExecutor(String receiverId,
                       int messageType,
                       int status,
                       Handler handler) {
            this.receiverId = receiverId;
            this.messageType = messageType;
            this.status = status;
            this.handler = handler;
        }

        @Override
        protected List<String> doInBackground(Void... voids) {
            List<String> messages = dB.getUnseenMessageIds(receiverId,
                    messageType,
                    Message.DELIVERED);
            System.out.println("lllllllllllllllllllll "+messages);
            if (messages != null && messages.size() > 0) {
                dB.updateSeenStatusForAll(receiverId,
                        messageType,
                        status,
                        Message.DELIVERED);
            }
            return messages;
        }

        @Override
        protected void onPostExecute(List<String> messageIds) {
            super.onPostExecute(messageIds);
            if (handler != null) {
                android.os.Message message = new android.os.Message();
                if (messageIds != null) {
                    Bundle bundle = new Bundle();
                    bundle.putStringArray(DATA_MESSAGE_IDS, messageIds.toArray(new String[messageIds.size()]));
                    message.setData(bundle);
                }
                handler.sendMessage(message);
            }
        }
    }

    public interface OnMessageStatusChangedListener {
        void onStatusChanged(@Nullable String... messageIds);
    }

}
