package in.tagteen.tagteen.chatting.room;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.content.Context;

import in.tagteen.tagteen.chatting.socket.ChatProcessLifecycleManager;

@Database(entities = {Message.class}, version = 1, exportSchema = false)
public abstract class MessageDatabase extends RoomDatabase {

    private static MessageDatabase database;

    public static MessageDatabase getInstance() {
        if (database == null)
            database = Room.databaseBuilder(ChatProcessLifecycleManager.getApplicationContext(),
                    MessageDatabase.class, "message_db").build();
        return database;
    }

    public abstract MessageDao getMessageDao();

}
