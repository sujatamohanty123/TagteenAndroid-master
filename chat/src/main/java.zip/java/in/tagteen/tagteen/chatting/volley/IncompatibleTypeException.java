package in.tagteen.tagteen.chatting.volley;

/**
 * Created by Tony on 12/25/2017.
 */

public class IncompatibleTypeException extends RuntimeException {

    public IncompatibleTypeException() {
        super("Required an array type of class");
    }
}