package in.tagteen.tagteen.chatting.room;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;
import android.support.annotation.NonNull;

import java.util.ArrayList;
import java.util.List;

@Dao
public interface MessageDao {

    @Query("SELECT serial_id FROM Message WHERE client_id IN(:receiverId) AND serial_id>(:offset)")
    List<Integer> getTotalMessageIds(@NonNull String receiverId,
                                     int offset);

    @Query("SELECT * FROM Message WHERE client_id IN(:receiverId) AND serial_id <= (:startId) AND serial_id >= (:endId)")
    List<Message> getMessages(@NonNull String receiverId,
                              int startId,
                              int endId);

    @Query("SELECT * FROM Message ORDER BY serial_id DESC LIMIT 1")
    LiveData<Message> getMessage();

    @Query("SELECT * FROM Message WHERE client_id IN(:receiverId) ORDER BY serial_id DESC LIMIT 1")
    Message getMessageByReceiverId(@NonNull String receiverId);

    @Insert
    void addMessage(@NonNull Message message);

//    @Query("SELECT COUNT(*) FROM Message WHERE client_id IN(:receiverId)")
//    int getMessagesCount(@NonNull String receiverId);

//    @Query("UPDATE Message SET server_message_id = :serverMessageId, server_date = :serverDate WHERE message_id IN(:messageId) AND client_id IN(:receiverId)")
//    void updateMessage(@NonNull String messageId,
//                       @NonNull String serverMessageId,
//                       @NonNull String receiverId,
//                       @NonNull long serverDate);

    @Query("UPDATE Message SET server_message_id = :serverMessageId, server_date = :serverDate, status = :status WHERE message_id IN(:messageId) AND client_id IN(:receiverId)")
    void updateMessage(@NonNull String serverMessageId,
                       long serverDate,
                       @Message.Status int status,
                       @NonNull String messageId,
                       @NonNull String receiverId);

    @Query("UPDATE Message SET status = :status WHERE client_id IN(:receiverId) AND server_message_id IN(:serverMessageIds)")
    void updateMessageStatus(@NonNull String receiverId,
                             @Message.Status int status,
                             @NonNull String... serverMessageIds);

    @Query("UPDATE Message SET status = :statusTo WHERE client_id IN(:receiverId) AND type IN(:messageType) AND status IN(:statusIn)")
    void updateSeenStatusForAll(@NonNull String receiverId,
                                @Message.Type int messageType,
                                @Message.Status int statusTo,
                                @Message.Status int statusIn);

//    @Query("SELECT message_id FROM Message WHERE client_id IN(:receiverId) AND type IN(:messageType) AND status IN(:statusIn)")
//    List<String> getUnSeenOutGoingMessageIds(@NonNull String receiverId,
//                                             @Message.Type int messageType,
//                                             @Message.Status int statusIn);

    @Query("SELECT server_message_id FROM Message WHERE client_id IN(:receiverId) AND type IN(:messageType) AND status IN(:status)")
    List<String> getUnseenMessageIds(@NonNull String receiverId,
                                          @Message.Type int messageType,
                                          @Message.Status int status);

    @Query("SELECT COUNT(*) FROM Message WHERE client_id IN(:receiverId) AND type IN(:messageType) AND status NOT IN(:status)")
    int getUnseenInMessageCount(@NonNull String receiverId,
                                @Message.Type int messageType,
                                @Message.Status int status);

    @Query("SELECT message_id FROM Message WHERE message_id IN(:messageId) AND client_id IN(:receiverId)")
    String getMessageId(@NonNull String messageId, @NonNull String receiverId);
}
