package in.tagteen.tagteen.chatting.room;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;

import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import in.tagteen.tagteen.chatting.room.tasks.TaskCallable;
import in.tagteen.tagteen.chatting.room.tasks.TaskRunnable;

/**
 * Handling Database communication
 */
public class ChatDB {

    private static final ExecutorService executor = Executors.newSingleThreadExecutor();

    public static void executeTask(@NonNull TaskRunnable task) {
        executor.execute(task);
    }

    public static <T> T submitTask(@NonNull TaskCallable<T> task) throws ExecutionException, InterruptedException {
        Future<T> future = executor.submit(task);
        return future.get();
    }

    public static  <T> T submitTask(@NonNull TaskRunnable task,
                            T result) throws ExecutionException, InterruptedException {
        Future<T> future = executor.submit(task, result);
        return future.get();
    }

    public static <T> Future submit(@NonNull TaskRunnable task,
                             T result) {
        return executor.submit(task, result);
    }

}
