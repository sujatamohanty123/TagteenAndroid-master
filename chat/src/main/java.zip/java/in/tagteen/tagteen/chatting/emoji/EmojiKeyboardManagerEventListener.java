package in.tagteen.tagteen.chatting.emoji;

import android.view.View;

/**
 * Created by tony00 on 3/23/2019.
 */
public interface EmojiKeyboardManagerEventListener {

    void onEmojiIconClick(View view);

    void onEditTextClick(View view);

}
