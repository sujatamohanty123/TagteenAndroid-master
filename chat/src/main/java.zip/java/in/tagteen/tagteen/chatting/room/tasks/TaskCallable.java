package in.tagteen.tagteen.chatting.room.tasks;

import java.util.concurrent.Callable;

import in.tagteen.tagteen.chatting.room.MessageDao;
import in.tagteen.tagteen.chatting.room.MessageDatabase;

/**
 * Created by tony00 on 6/1/2019.
 */
public interface TaskCallable<V> extends Callable<V> {

    String TAG = "TaskCallable.TAG";

    MessageDao dB = MessageDatabase.getInstance().getMessageDao();
}
