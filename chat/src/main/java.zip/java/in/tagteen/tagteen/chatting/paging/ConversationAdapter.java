package in.tagteen.tagteen.chatting.paging;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.ViewGroup;

import java.util.List;

import in.tagteen.tagteen.chatting.emoji.EmojiPlayer;
import in.tagteen.tagteen.chatting.model.MessageStatus;
import in.tagteen.tagteen.chatting.room.Message;
import in.tagteen.tagteen.chatting.socket.SocketConstants;

/**
 * Created by tony00 on 11/16/2018.
 */
public class ConversationAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private ConversationViewBuilder cBuilder;
    private EmojiPlayer emojiPlayer;
    private boolean canPlayEmoji = false;

    ConversationAdapter(Context context) {
        cBuilder = new ConversationViewBuilder();
        emojiPlayer = EmojiPlayer.createPlayer(context);
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ConversationViewHolder cVHolder = new ConversationViewHolder();
        return cVHolder.new Holders().get(parent, viewType);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        int type = getItemViewType(position);

        if (type == ConversationModel.ConversationItemType.TYPE_TEXT_INCOMING
                || type == ConversationModel.ConversationItemType.TYPE_TEXT_OUTGOING)
            ((ConversationViewHolder.MessageViewHolder) holder)
                    .bind((ConversationModel.Content) cBuilder.getModel().itemAt(position));
        else if (type == ConversationModel.ConversationItemType.TYPE_DAY)
            ((ConversationViewHolder.DayViewHolder) holder)
                    .bind((ConversationModel.Day) cBuilder.getModel().itemAt(position));
        else if (type == ConversationModel.ConversationItemType.TYPE_SOUND_EMOJI_INCOMING
                || type == ConversationModel.ConversationItemType.TYPE_SOUND_EMOJI_OUTGOING) {
            ConversationViewHolder.EmojiViewHolder emojiHolder = ((ConversationViewHolder.EmojiViewHolder) holder);
            emojiHolder.bind((ConversationModel.SoundEmoji) cBuilder.getModel().itemAt(position));

            if (canPlayEmoji && position == getItemCount() - 1) {
                canPlayEmoji = false;
                emojiPlayer.play(Integer.parseInt(((ConversationModel.SoundEmoji)
                        cBuilder.getModel().itemAt(position)).getMessage().getMessage()));
            }

            emojiHolder.setEmojiSelectListener(emojiId -> {
                emojiPlayer.play(emojiId);
            });
        }
    }

    @Override
    public int getItemCount() {
        return cBuilder.getModel().count();
    }

    @Override
    public int getItemViewType(int position) {
        return cBuilder.getModel().type(position);
    }

    void submitList(List<Message> list, boolean areMoreMessagesAvailable) {
        cBuilder.submitMessages(list, areMoreMessagesAvailable);
        notifyDataSetChanged();
    }

    public void addMessage(Message message, boolean isDrafted) {
        cBuilder.addMessage(message, isDrafted);
        canPlayEmoji = message.getChatType() == SocketConstants.MessageType.SOUND_EMOJI
                && message.getMessageType() == Message.MESSAGE_IN
                && !isDrafted;
        notifyDataSetChanged();
    }

    public void addMessages(List<Message> messages) {
        cBuilder.addMessages(messages);
        notifyDataSetChanged();
    }

    public void updateMessage(MessageStatus status, String... messageIds) {
        cBuilder.updateMessage(status, messageIds);
        notifyDataSetChanged();
    }

    public boolean contains(Message message) {
        return InterpolationSearch.findMessageAdapterPosition(cBuilder.getMessages(), message.getId()) != -1;
    }

}
