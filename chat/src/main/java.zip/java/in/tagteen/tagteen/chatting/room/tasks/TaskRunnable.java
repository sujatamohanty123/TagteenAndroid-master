package in.tagteen.tagteen.chatting.room.tasks;

import android.os.Handler;
import android.os.Looper;

import in.tagteen.tagteen.chatting.room.MessageDao;
import in.tagteen.tagteen.chatting.room.MessageDatabase;
import in.tagteen.tagteen.chatting.socket.MainThreadExecutor;

/**
 * Created by tony00 on 6/1/2019.
 */
public interface TaskRunnable extends Runnable, MainThreadExecutor {

    String TAG = "TaskRunnable.TAG";

    MessageDao dB = MessageDatabase.getInstance().getMessageDao();

}
