package in.tagteen.tagteen.chatting.room.tasks;

import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.util.Log;

import in.tagteen.tagteen.chatting.room.Message;

/**
 * Created by tony00 on 6/1/2019.
 */
public class NewOfflineMessageTask implements TaskRunnable {
    private Message message;

    public NewOfflineMessageTask(@NonNull Message message) {
        Log.d(TAG, "Checking Messages...");
        this.message = message;
    }

    @Override
    public void run() {
        String messageId = dB.getMessageId(message.getMsgId(), message.getClientId());
        Log.d(TAG, "Message id... " + messageId);

        if (TextUtils.isEmpty(messageId))
            dB.addMessage(message);
        else
            dB.updateMessage(message.getServerMsgId(),
                    message.getServerDate(),
                    message.getMessageStatus(),
                    message.getMsgId(),
                    message.getClientId());
    }
}
