package in.tagteen.tagteen.chatting.volley;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

public class VolleyResponse<T> {

    public interface JsonResponseHandler<T> {

        void OnResponseParsed(int requestTag,
                              @Nullable T unMarshalledObject);
    }

    public interface ResponseListener<T> {

        void onDataResponse(@NonNull RequestResponse<T> response);

    }

}
