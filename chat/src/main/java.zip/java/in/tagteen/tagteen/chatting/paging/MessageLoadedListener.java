package in.tagteen.tagteen.chatting.paging;

import android.support.annotation.NonNull;

import in.tagteen.tagteen.chatting.room.Message;

import java.util.List;

/**
 * Created by tony00 on 3/30/2019.
 */
public interface MessageLoadedListener {

    void onLoadedBefore(@NonNull List<Message> messages,
                        boolean areMoreMessagesAvailable);

    void onLoadedAfter(@NonNull List<Message> messages);

    void onNewMessage(@NonNull Message message, boolean isDrafted);

}
