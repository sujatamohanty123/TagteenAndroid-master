package in.tagteen.tagteen.chatting.room.tasks;

import android.support.annotation.NonNull;
import android.util.Log;

import in.tagteen.tagteen.chatting.room.Message;

/**
 * Created by tony00 on 6/1/2019.
 */
public class MessagesCountTask implements TaskCallable<Integer> {

    private String receiverId;

    public MessagesCountTask(@NonNull String receiverId) {
        Log.d(TAG, "Retrieving UnSeen Messages Count...");
        this.receiverId = receiverId;
    }

    @Override
    public Integer call() throws Exception {
        return dB.getUnseenInMessageCount(receiverId,
                Message.MESSAGE_IN,
                Message.SEEN);
    }
}
