package in.tagteen.tagteen.chatting.room.tasks;

import android.support.annotation.NonNull;
import android.util.Log;

import java.util.List;

import in.tagteen.tagteen.chatting.room.Message;

/**
 * Created by tony00 on 6/18/2019.
 */
public class MessageStatusTask implements TaskRunnable {

    private String receiverId;
    private String[] serverMessageIds;
    private int status;

    public MessageStatusTask(@NonNull String receiverId,
                             @Message.Status int status,
                             @NonNull String... serverMessageIds) {
        Log.d(TAG, "Updating Message Status: " + status);
        this.receiverId = receiverId;
        this.serverMessageIds = serverMessageIds;
        this.status = status;
    }

    @Override
    public void run() {
        dB.updateMessageStatus(receiverId,
                status,
                serverMessageIds);
    }
}
