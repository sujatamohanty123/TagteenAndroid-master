package in.tagteen.tagteen.chatting.viewmodels;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.ViewModel;
import android.arch.paging.DataSource;
import android.arch.paging.LivePagedListBuilder;
import android.arch.paging.PagedList;
import android.content.Context;

import in.tagteen.tagteen.chatting.room.Message;
import in.tagteen.tagteen.chatting.room.MessageDao;
import in.tagteen.tagteen.chatting.room.MessageDatabase;

public class ChatDetailViewModel extends ViewModel {

    private LiveData<PagedList<Message>> messageList;

    public void init(Context context, String receiverId) {
//        MessageDao db = MessageDatabase.getApplicationContext(context).getMessageDao();
//        DataSource.Factory<Integer, Message> messageDataSource = db.getMessages(receiverId);
//
//        LivePagedListBuilder<Integer, Message> pagedListBuilder =
//                new LivePagedListBuilder<Integer, Message>(messageDataSource, 30);
//        messageList = pagedListBuilder.build();
    }

    public LiveData<PagedList<Message>> getMessageList() {
        return messageList;
    }

}