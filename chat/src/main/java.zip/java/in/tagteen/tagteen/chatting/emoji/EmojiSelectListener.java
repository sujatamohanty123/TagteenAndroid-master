package in.tagteen.tagteen.chatting.emoji;

/**
 * Created by lovekushvishwakarma on 12/09/17.
 */

public interface EmojiSelectListener {

    void onEmojiSelect(int emojiId);

}
