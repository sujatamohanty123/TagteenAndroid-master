package in.tagteen.tagteen.chatting.room.tasks;

import android.os.Handler;
import android.support.annotation.NonNull;
import android.util.Log;

import java.util.List;

import in.tagteen.tagteen.chatting.room.Message;

/**
 * Created by tony00 on 6/1/2019.
 */
public class MessagesListTask implements TaskRunnable {

    private String receiverId;
    private Handler handler;
    private OnMessagesFoundListener callback;

    public MessagesListTask(@NonNull String receiverId) {
        Log.d(TAG, "Counting Messages:");

        this.receiverId = receiverId;
    }

    @Override
    public void run() {
        List<String> messageIds = dB.getUnseenMessageIds(receiverId,
                Message.MESSAGE_IN,
                Message.DELIVERED);

        if (messageIds != null &&
                messageIds.size() > 0 &&
                callback != null)
            runOnMainThread(() -> callback.onMessagesFound(messageIds.toArray(new String[messageIds.size()])));
    }

    public void setOnMessagesFoundListener(OnMessagesFoundListener callback) {
        this.callback = callback;
    }

    public interface OnMessagesFoundListener {
        void onMessagesFound(@NonNull String... messageIds);
    }
}
