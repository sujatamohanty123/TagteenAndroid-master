package in.tagteen.tagteen.chatting.room.tasks;

import android.support.annotation.NonNull;
import android.util.Log;

import in.tagteen.tagteen.chatting.room.Message;

/**
 * Created by tony00 on 6/1/2019.
 */
public class NewMessageTask implements TaskRunnable {

    private Message message;

    public NewMessageTask(@NonNull Message message) {
        Log.d(TAG, "Saving new Message: ");
        this.message = message;
    }

    @Override
    public void run() {
//        android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND);
        dB.addMessage(message);
    }
}
