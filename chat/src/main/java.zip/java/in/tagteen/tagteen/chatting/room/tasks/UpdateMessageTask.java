package in.tagteen.tagteen.chatting.room.tasks;

import android.support.annotation.NonNull;
import android.util.Log;

import in.tagteen.tagteen.chatting.room.Message;

/**
 * Created by tony00 on 6/1/2019.
 */
public class UpdateMessageTask implements TaskRunnable {

    private String messageId;
    private String serverMessageId;
    private String receiverId;
    private long serverDate;

    public UpdateMessageTask(@NonNull String messageId,
                             @NonNull String serverMessageId,
                             @NonNull String receiverId,
                             long serverDate) {
        Log.d(TAG, "Updating Message: ");
        this.messageId = messageId;
        this.serverMessageId = serverMessageId;
        this.receiverId = receiverId;
        this.serverDate = serverDate;
    }

    @Override
    public void run() {
        dB.updateMessage(
                serverMessageId,
                serverDate,
                Message.SENT,
                messageId,
                receiverId);
    }
}
