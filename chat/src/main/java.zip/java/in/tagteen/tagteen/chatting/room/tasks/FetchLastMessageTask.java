package in.tagteen.tagteen.chatting.room.tasks;

import android.support.annotation.NonNull;
import android.util.Log;

import in.tagteen.tagteen.chatting.room.Message;

/**
 * Created by tony00 on 6/1/2019.
 */
public class FetchLastMessageTask implements TaskCallable<Message> {

    private String receiverId;

    public FetchLastMessageTask(@NonNull String receiverId) {
        Log.d(TAG, "Retrieving Last Message...");
        this.receiverId = receiverId;
    }

    @Override
    public Message call() throws Exception {
        return dB.getMessageByReceiverId(receiverId);
    }
}
